# Blender UI Components Add-On - Component Creation Operators
# Compatible with Blender 4.0+ and Windows 10 64-bit+
# Production Environment Code - Version 1.0.12

import bpy
from bpy.types import Operator
from . import utils
import traceback
import sys

# Enhanced error handling decorator for operators
def handle_operator_errors(func):
    """Decorator to handle operator errors and provide debugging information"""
    def wrapper(self, context):
        try:
            return func(self, context)
        except Exception as e:
            # Print detailed error information
            error_msg = f"UI Components Add-On Error in {func.__name__}: {str(e)}"
            print(error_msg)
            print("Full traceback:")
            traceback.print_exc()
            
            # Attempt to open system console for debugging
            try:
                if sys.platform == 'win32':
                    bpy.ops.wm.console_toggle()
            except:
                pass
            
            # Show error message to user
            self.report({'ERROR'}, f"Operation failed: {str(e)}")
            return {'CANCELLED'}
    
    return wrapper

# Operator Classes for Component Creation
class MESH_OT_add_ui_window(Operator):
    """Create a versatile main window panel with titlebar and individual material options"""
    bl_idname = "mesh.add_ui_window"
    bl_label = "Add UI Window"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_window_props
        
        # Create main window panel
        main_verts, main_faces = utils.create_rounded_rectangle(
            props.width, props.height, props.corner_radius
        )
        
        main_window = utils.create_mesh_with_uvs(context, "UI_Window_Main", main_verts, main_faces)
        
        # Apply window material with transparency
        window_mat = utils.get_or_create_material(
            props.main_material, 
            props.main_material_name, 
            (0.9, 0.9, 0.95, 1.0),
            props.main_transparency
        )
        main_window.data.materials.append(window_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create titlebar if enabled
        if props.has_titlebar:
            titlebar_verts, titlebar_faces = utils.create_rounded_rectangle(
                props.width, props.titlebar_height, props.corner_radius * 0.5
            )
            
            titlebar = utils.create_mesh_with_uvs(context, "UI_Window_Titlebar", titlebar_verts, titlebar_faces)
            titlebar.location.y = props.height * 0.5 + props.titlebar_height * 0.5
            
            # Apply titlebar material with transparency
            titlebar_mat = utils.get_or_create_material(
                props.titlebar_material,
                props.titlebar_material_name,
                (0.3, 0.4, 0.6, 1.0),
                props.titlebar_transparency
            )
            titlebar.data.materials.append(titlebar_mat)
            sub_components.append(titlebar)
            
            # Create close button if enabled
            if props.close_button:
                button_radius = props.titlebar_height * 0.3
                close_verts, close_faces = utils.create_circle_mesh(button_radius)
                
                close_button = utils.create_mesh_with_uvs(context, "UI_Window_CloseButton", close_verts, close_faces)
                close_button.location.x = props.width * 0.5 - button_radius * 2
                close_button.location.y = props.height * 0.5 + props.titlebar_height * 0.5
                close_button.location.z = 0.01
                
                # Apply close button material with individual material options
                close_mat = utils.get_or_create_material(
                    props.close_button_material,
                    props.close_button_material_name,
                    (0.8, 0.2, 0.2, 1.0),
                    props.close_button_transparency
                )
                close_button.data.materials.append(close_mat)
                sub_components.append(close_button)
            
            # Create minimize button if enabled
            if props.minimize_button:
                button_radius = props.titlebar_height * 0.3
                min_verts, min_faces = utils.create_circle_mesh(button_radius)
                
                minimize_button = utils.create_mesh_with_uvs(context, "UI_Window_MinimizeButton", min_verts, min_faces)
                minimize_button.location.x = props.width * 0.5 - button_radius * 4.5
                minimize_button.location.y = props.height * 0.5 + props.titlebar_height * 0.5
                minimize_button.location.z = 0.01
                
                # Apply minimize button material with individual material options
                min_mat = utils.get_or_create_material(
                    props.minimize_button_material,
                    props.minimize_button_material_name,
                    (0.2, 0.6, 0.2, 1.0),
                    props.minimize_button_transparency
                )
                minimize_button.data.materials.append(min_mat)
                sub_components.append(minimize_button)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_Window_Group", 
            main_window, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_button(Operator):
    """Create a button component with properly rounded corners, 3D depth, and enhanced border system"""
    bl_idname = "mesh.add_ui_button"
    bl_label = "Add UI Button"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_button_props
        
        # Create main button using enhanced rounded mesh function
        main_button = utils.create_rounded_button_mesh(
            context, 
            "UI_Button", 
            props.width, 
            props.height, 
            props.depth, 
            props.corner_radius,
            props.bevel_segments
        )
        
        # Apply main button material with transparency
        button_mat = utils.get_or_create_material(
            props.main_material,
            props.main_material_name,
            (0.7, 0.7, 0.9, 1.0),
            props.main_transparency
        )
        main_button.data.materials.append(button_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create inward border if specified
        if props.border_width > 0.001:
            border_verts, border_faces = utils.create_inward_border_rectangle(
                props.width, props.height, props.border_width, props.corner_radius
            )
            
            border_obj = utils.create_mesh_with_uvs(context, "UI_Button_Border", border_verts, border_faces)
            border_obj.location.z = props.depth * 0.5 + 0.001  # Place border on top surface
            
            # Apply border material with transparency
            border_mat = utils.get_or_create_material(
                props.border_material,
                props.border_material_name,
                (0.3, 0.3, 0.3, 1.0),
                props.border_transparency
            )
            border_obj.data.materials.append(border_mat)
            sub_components.append(border_obj)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_Button_Group", 
            main_button, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_scrollbar(Operator):
    """Create horizontal or vertical scrollbar with directional arrows, track knob, and enhanced materials"""
    bl_idname = "mesh.add_ui_scrollbar"
    bl_label = "Add UI Scrollbar"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_scrollbar_props
        
        # Create enhanced scrollbar track with embossed appearance and curved corners
        scrollbar_track = utils.create_enhanced_scrollbar_track_mesh(
            context,
            "UI_Scrollbar_Track",
            props.length,
            props.width,
            props.orientation,
            props.corner_radius,
            props.embossed,
            props.emboss_depth
        )
        
        # Apply track material with transparency
        track_mat = utils.get_or_create_material(
            props.track_material,
            props.track_material_name,
            (0.6, 0.6, 0.6, 1.0),
            props.track_transparency
        )
        scrollbar_track.data.materials.append(track_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create track knob if enabled
        if props.has_track_knob:
            # Calculate knob length based on track knob size setting
            knob_length = props.length * props.track_knob_size
            
            # CRITICAL FIX: Make track knob narrower for clear visual separation
            track_knob = utils.create_scrollbar_track_knob_mesh(
                context,
                "UI_Scrollbar_TrackKnob",
                knob_length,
                props.width * 0.7,  # FIXED: Much narrower than main track for clear separation
                props.orientation
            )
            
            # Position track knob based on track knob position property
            if props.orientation == 'VERTICAL':
                # Calculate available movement range (total length minus knob length)
                movement_range = props.length - knob_length
                knob_y = (props.track_knob_position - 0.5) * movement_range
                track_knob.location.y = knob_y
                track_knob.location.z = props.width * 0.25  # Raised above track for visibility
            else:
                # Calculate available movement range (total length minus knob length)
                movement_range = props.length - knob_length
                knob_x = (props.track_knob_position - 0.5) * movement_range
                track_knob.location.x = knob_x
                track_knob.location.z = props.width * 0.25  # Raised above track for visibility
            
            # Apply track knob material with transparency
            knob_mat = utils.get_or_create_material(
                props.track_knob_material,
                props.track_knob_material_name,
                (0.8, 0.8, 0.9, 1.0),
                props.track_knob_transparency
            )
            track_knob.data.materials.append(knob_mat)
            sub_components.append(track_knob)
        
        # Create directional arrows with enhanced material system
        arrow_mat = utils.get_or_create_material(
            props.arrow_material,
            props.arrow_material_name,
            (0.4, 0.4, 0.4, 1.0),
            props.arrow_transparency
        )
        
        if props.orientation == 'VERTICAL':
            # Up arrow
            up_arrow_verts, up_arrow_faces = utils.create_arrow_mesh(props.arrow_size, 'UP')
            up_arrow = utils.create_mesh_with_uvs(context, "UI_Scrollbar_UpArrow", up_arrow_verts, up_arrow_faces)
            up_arrow.location.y = props.length * 0.5 - props.arrow_size
            up_arrow.location.z = 0.01
            up_arrow.data.materials.append(arrow_mat)
            sub_components.append(up_arrow)
            
            # Down arrow
            down_arrow_verts, down_arrow_faces = utils.create_arrow_mesh(props.arrow_size, 'DOWN')
            down_arrow = utils.create_mesh_with_uvs(context, "UI_Scrollbar_DownArrow", down_arrow_verts, down_arrow_faces)
            down_arrow.location.y = -props.length * 0.5 + props.arrow_size
            down_arrow.location.z = 0.01
            down_arrow.data.materials.append(arrow_mat)
            sub_components.append(down_arrow)
        else:
            # Left arrow
            left_arrow_verts, left_arrow_faces = utils.create_arrow_mesh(props.arrow_size, 'LEFT')
            left_arrow = utils.create_mesh_with_uvs(context, "UI_Scrollbar_LeftArrow", left_arrow_verts, left_arrow_faces)
            left_arrow.location.x = -props.length * 0.5 + props.arrow_size
            left_arrow.location.z = 0.01
            left_arrow.data.materials.append(arrow_mat)
            sub_components.append(left_arrow)
            
            # Right arrow
            right_arrow_verts, right_arrow_faces = utils.create_arrow_mesh(props.arrow_size, 'RIGHT')
            right_arrow = utils.create_mesh_with_uvs(context, "UI_Scrollbar_RightArrow", right_arrow_verts, right_arrow_faces)
            right_arrow.location.x = props.length * 0.5 - props.arrow_size
            right_arrow.location.z = 0.01
            right_arrow.data.materials.append(arrow_mat)
            sub_components.append(right_arrow)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_Scrollbar_Group", 
            scrollbar_track, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_checkbox(Operator):
    """Create enhanced square or circular checkbox with inward border and checked state"""
    bl_idname = "mesh.add_ui_checkbox"
    bl_label = "Add UI Checkbox"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_checkbox_props
        
        # Create main checkbox background
        if props.shape_type == 'SQUARE':
            main_verts, main_faces = utils.create_rounded_rectangle(
                props.size, props.size, props.size * 0.05
            )
        else:
            main_verts, main_faces = utils.create_circle_mesh(props.size * 0.5)
        
        checkbox_main = utils.create_mesh_with_uvs(context, "UI_Checkbox_Main", main_verts, main_faces)
        
        # Apply main checkbox material with transparency
        main_mat = utils.get_or_create_material(
            props.main_material,
            props.main_material_name,
            (0.9, 0.9, 0.9, 1.0),
            props.main_transparency
        )
        checkbox_main.data.materials.append(main_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create inward border if specified
        if props.border_width > 0.001:
            if props.shape_type == 'SQUARE':
                border_verts, border_faces = utils.create_inward_border_rectangle(
                    props.size, props.size, props.border_width, props.size * 0.05
                )
            else:
                # Create circular border (ring shape)
                outer_radius = props.size * 0.5
                inner_radius = max(0.01, outer_radius - props.border_width)
                border_verts, border_faces = utils.create_circle_border_mesh(outer_radius, inner_radius)
            
            checkbox_border = utils.create_mesh_with_uvs(context, "UI_Checkbox_Border", border_verts, border_faces)
            checkbox_border.location.z = 0.001
            
            # Apply border material with transparency
            border_mat = utils.get_or_create_material(
                props.border_material,
                props.border_material_name,
                (0.4, 0.4, 0.4, 1.0),
                props.border_transparency
            )
            checkbox_border.data.materials.append(border_mat)
            sub_components.append(checkbox_border)
        
        # Create checked state indicator if enabled
        if props.is_checked:
            # Calculate checked indicator size (smaller than main size, accounting for border)
            indicator_size = props.size - (props.border_width * 4)  # Leave space around border
            indicator_size = max(0.05, indicator_size)  # Minimum size protection
            
            if props.shape_type == 'SQUARE':
                checked_verts, checked_faces = utils.create_rounded_rectangle(
                    indicator_size, indicator_size, indicator_size * 0.05
                )
            else:
                checked_verts, checked_faces = utils.create_circle_mesh(indicator_size * 0.5)
            
            checkbox_checked = utils.create_mesh_with_uvs(context, "UI_Checkbox_Checked", checked_verts, checked_faces)
            checkbox_checked.location.z = 0.002
            
            # Apply checked state material with transparency
            checked_mat = utils.get_or_create_material(
                props.checked_material,
                props.checked_material_name,
                (0.2, 0.6, 0.2, 1.0),
                props.checked_transparency
            )
            checkbox_checked.data.materials.append(checked_mat)
            sub_components.append(checkbox_checked)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_Checkbox_Group", 
            checkbox_main, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_tabbed_panel(Operator):
    """Create tabbed panel system with multiple tabs, content area and enhanced materials"""
    bl_idname = "mesh.add_ui_tabbed_panel"
    bl_label = "Add UI Tabbed Panel"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_tabbed_panel_props
        
        # Create main content panel
        panel_verts, panel_faces = utils.create_rounded_rectangle(
            props.panel_width, props.panel_height, props.border_width * 2
        )
        
        main_panel = utils.create_mesh_with_uvs(context, "UI_TabbedPanel_Content", panel_verts, panel_faces)
        
        # Apply content material with transparency
        content_mat = utils.get_or_create_material(
            props.content_material,
            props.content_material_name,
            (0.95, 0.95, 0.95, 1.0),
            props.content_transparency
        )
        main_panel.data.materials.append(content_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create tabs with enhanced material system
        tab_width = props.panel_width / props.tab_count
        
        for i in range(props.tab_count):
            tab_verts, tab_faces = utils.create_rounded_rectangle(
                tab_width - props.border_width, props.tab_height, props.border_width
            )
            
            tab = utils.create_mesh_with_uvs(context, f"UI_TabbedPanel_Tab_{i+1}", tab_verts, tab_faces)
            
            # Position tab
            tab_x_offset = -props.panel_width * 0.5 + tab_width * 0.5 + (i * tab_width)
            tab.location.x = tab_x_offset
            tab.location.y = props.panel_height * 0.5 + props.tab_height * 0.5
            tab.location.z = 0.01
            
            # Apply tab material based on active state
            if i == 0:  # First tab is active
                tab_mat = utils.get_or_create_material(
                    props.active_tab_material,
                    props.active_tab_material_name,
                    (0.8, 0.8, 1.0, 1.0),
                    props.active_tab_transparency
                )
            else:  # Other tabs are inactive
                tab_mat = utils.get_or_create_material(
                    props.inactive_tab_material,
                    props.inactive_tab_material_name,
                    (0.7, 0.7, 0.7, 1.0),
                    props.inactive_tab_transparency
                )
            
            tab.data.materials.append(tab_mat)
            sub_components.append(tab)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_TabbedPanel_Group", 
            main_panel, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_slider(Operator):
    """Create horizontal or vertical slider with enhanced embossed appearance, curved corners, and selector knob"""
    bl_idname = "mesh.add_ui_slider"
    bl_label = "Add UI Slider"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_slider_props
        
        # Create enhanced slider track with embossed appearance and curved corners
        slider_track = utils.create_enhanced_slider_track_mesh(
            context,
            "UI_Slider_Track",
            props.length,
            props.track_width,
            props.orientation,
            props.corner_radius,
            props.embossed,
            props.emboss_depth
        )
        
        # Apply track material with transparency
        track_mat = utils.get_or_create_material(
            props.track_material,
            props.track_material_name,
            (0.5, 0.5, 0.5, 1.0),
            props.track_transparency
        )
        slider_track.data.materials.append(track_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create slider knob using enhanced mesh generation
        slider_knob = utils.create_slider_knob_mesh(
            context,
            "UI_Slider_Knob",
            props.knob_size
        )
        
        # Position knob based on knob_position property
        if props.orientation == 'HORIZONTAL':
            knob_x = (props.knob_position - 0.5) * (props.length - props.knob_size)
            slider_knob.location.x = knob_x
            slider_knob.location.z = props.knob_size * 0.3
        else:
            knob_y = (props.knob_position - 0.5) * (props.length - props.knob_size)
            slider_knob.location.y = knob_y
            slider_knob.location.z = props.knob_size * 0.3
        
        # Apply knob material with transparency
        knob_mat = utils.get_or_create_material(
            props.knob_material,
            props.knob_material_name,
            (0.8, 0.8, 0.9, 1.0),
            props.knob_transparency
        )
        slider_knob.data.materials.append(knob_mat)
        sub_components.append(slider_knob)
        
        # Create inward border if specified
        if props.border_width > 0.001:
            if props.orientation == 'HORIZONTAL':
                border_verts, border_faces = utils.create_inward_border_rectangle(
                    props.length, props.track_width, props.border_width, props.corner_radius
                )
            else:
                border_verts, border_faces = utils.create_inward_border_rectangle(
                    props.track_width, props.length, props.border_width, props.corner_radius
                )
            
            slider_border = utils.create_mesh_with_uvs(context, "UI_Slider_Border", border_verts, border_faces)
            slider_border.location.z = 0.001
            
            # Apply border material with transparency
            border_mat = utils.get_or_create_material(
                props.border_material,
                props.border_material_name,
                (0.3, 0.3, 0.3, 1.0),
                props.border_transparency
            )
            slider_border.data.materials.append(border_mat)
            sub_components.append(slider_border)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_Slider_Group", 
            slider_track, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_banner(Operator):
    """Create banner component for headers and announcements with enhanced border system"""
    bl_idname = "mesh.add_ui_banner"
    bl_label = "Add UI Banner"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_banner_props
        
        # Create main banner mesh
        banner_verts, banner_faces = utils.create_rounded_rectangle(
            props.width, props.height, props.corner_radius
        )
        
        banner = utils.create_mesh_with_uvs(context, "UI_Banner", banner_verts, banner_faces)
        
        # Apply banner material with transparency
        banner_mat = utils.get_or_create_material(
            props.main_material,
            props.main_material_name,
            (0.2, 0.4, 0.8, 1.0),
            props.main_transparency
        )
        banner.data.materials.append(banner_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create inward border if specified
        if props.border_width > 0.001:
            border_verts, border_faces = utils.create_inward_border_rectangle(
                props.width, props.height, props.border_width, props.corner_radius
            )
            
            banner_border = utils.create_mesh_with_uvs(context, "UI_Banner_Border", border_verts, border_faces)
            banner_border.location.z = 0.001
            
            # Apply border material with transparency
            border_mat = utils.get_or_create_material(
                props.border_material,
                props.border_material_name,
                (0.1, 0.2, 0.4, 1.0),
                props.border_transparency
            )
            banner_border.data.materials.append(border_mat)
            sub_components.append(banner_border)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_Banner_Group", 
            banner, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_general_panel(Operator):
    """Create general purpose panel with configurable inward borders and enhanced materials"""
    bl_idname = "mesh.add_ui_general_panel"
    bl_label = "Add UI General Panel"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        props = context.scene.ui_general_panel_props
        
        # Create main panel mesh
        panel_verts, panel_faces = utils.create_rounded_rectangle(
            props.width, props.height, props.corner_radius
        )
        
        main_panel = utils.create_mesh_with_uvs(context, "UI_GeneralPanel", panel_verts, panel_faces)
        
        # Apply main panel material with transparency
        panel_mat = utils.get_or_create_material(
            props.main_material,
            props.main_material_name,
            (0.85, 0.85, 0.85, 1.0),
            props.main_transparency
        )
        main_panel.data.materials.append(panel_mat)
        
        # List to store sub-components for grouping
        sub_components = []
        
        # Create inward border if specified
        if props.border_width > 0.001:
            border_verts, border_faces = utils.create_inward_border_rectangle(
                props.width, props.height, props.border_width, props.corner_radius
            )
            
            border_panel = utils.create_mesh_with_uvs(context, "UI_GeneralPanel_Border", border_verts, border_faces)
            border_panel.location.z = 0.001
            
            # Apply border material with transparency
            border_mat = utils.get_or_create_material(
                props.border_material,
                props.border_material_name,
                (0.4, 0.4, 0.4, 1.0),
                props.border_transparency
            )
            border_panel.data.materials.append(border_mat)
            sub_components.append(border_panel)
        
        # Create component group with all sub-components
        group_controller, group_collection = utils.create_component_group(
            context, 
            "UI_GeneralPanel_Group", 
            main_panel, 
            sub_components
        )
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}

class MESH_OT_add_ui_combined_window(Operator):
    """Create complete window system with anchored components and enhanced materials"""
    bl_idname = "mesh.add_ui_combined_window"
    bl_label = "Add UI Combined Window System"
    bl_options = {'REGISTER', 'UNDO'}

    @handle_operator_errors
    def execute(self, context):
        # Get property groups
        window_props = context.scene.ui_window_props
        
        # Create main window first
        bpy.ops.mesh.add_ui_window()
        main_window_controller = context.active_object
        
        # Find the actual main window object (child of controller)
        main_window = None
        for child in main_window_controller.children:
            if "UI_Window_Main" in child.name:
                main_window = child
                break
        
        if main_window is None:
            self.report({'ERROR'}, "Failed to find main window component")
            return {'CANCELLED'}
        
        window_location = main_window.location.copy()
        
        # List to store all component controllers for the combined system
        component_controllers = [main_window_controller]
        
        # Create example button in window
        bpy.ops.mesh.add_ui_button()
        button_controller = context.active_object
        
        # Find the actual button object
        button = None
        for child in button_controller.children:
            if "UI_Button" in child.name:
                button = child
                break
        
        if button:
            button_controller.location.x = window_location.x - window_props.width * 0.3
            button_controller.location.y = window_location.y - window_props.height * 0.2
            button_controller.location.z = window_location.z + 0.02
            component_controllers.append(button_controller)
        
        # Create content panel inside window
        bpy.ops.mesh.add_ui_general_panel()
        panel_controller = context.active_object
        
        # Find the actual panel object
        panel = None
        for child in panel_controller.children:
            if "UI_GeneralPanel" in child.name:
                panel = child
                break
        
        if panel:
            panel_controller.scale = (0.8, 0.6, 1.0)
            panel_controller.location.x = window_location.x
            panel_controller.location.y = window_location.y - window_props.height * 0.1
            panel_controller.location.z = window_location.z + 0.01
            component_controllers.append(panel_controller)
        
        # Create master group for the complete window system
        master_controller, master_collection = utils.create_simple_component_group(
            context,
            "UI_CompleteWindow_System",
            component_controllers
        )
        
        # Select master controller as active
        context.view_layer.objects.active = master_controller
        
        # Focus sidebar and open UI Components tab
        utils.focus_ui_tab("UI Components")

        return {'FINISHED'}