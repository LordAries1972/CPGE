# Blender UI Components Add-On - Main Initialization File
# Compatible with Blender 4.0+ and Windows 10 64-bit+
# Production Environment Code - Version 1.0.12

bl_info = {
    "name": "UI Components Builder",
    "blender": (4, 0, 0),
    "category": "Add Mesh",
    "version": (1, 0, 12),
    "author": "Daniel J. Hobson, Australia",
    "description": "Create versatile UI components for interface design with enhanced embossed appearance, curved corners, track knobs, and CPGE game engine export support",
    "location": "View3D > Add > Mesh > UI Components",
    "warning": "",
    "doc_url": "",
    "support": 'COMMUNITY',
}

import bpy
import sys

# Import all required modules
from . import properties
from . import operators
from . import panels
from . import utils

# Error handling and console management for debugging
def enable_error_console():
    """Enable error console for debugging purposes"""
    try:
        # Attempt to open system console for error monitoring
        if sys.platform == 'win32':
            bpy.ops.wm.console_toggle()
    except Exception as e:
        print(f"UI Components Add-On: Console access limited - {e}")

# Custom UI Components menu - MOVED BEFORE classes tuple for proper registration order
class VIEW3D_MT_ui_components_menu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_ui_components_menu"
    bl_label = "UI Components"

    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.add_ui_window", text="UI Window Panel")
        layout.operator("mesh.add_ui_button", text="UI Button")
        layout.operator("mesh.add_ui_scrollbar", text="UI Enhanced Scrollbar")
        layout.operator("mesh.add_ui_checkbox", text="UI Enhanced Checkbox")
        layout.operator("mesh.add_ui_tabbed_panel", text="UI Tabbed Panel")
        layout.operator("mesh.add_ui_slider", text="UI Enhanced Slider")
        layout.operator("mesh.add_ui_banner", text="UI Banner")
        layout.operator("mesh.add_ui_general_panel", text="UI General Panel")
        layout.operator("mesh.add_ui_combined_window", text="UI Complete System")

# FIXED: Class registration list with proper order and no duplicates
classes = (
    # Property Groups from properties.py
    properties.UIWindowProperties,
    properties.UIButtonProperties,
    properties.UIScrollbarProperties,
    properties.UICheckboxProperties,
    properties.UITabbedPanelProperties,
    properties.UISliderProperties,
    properties.UIBannerProperties,
    properties.UIGeneralPanelProperties,
    
    # Operators from operators.py
    operators.MESH_OT_add_ui_window,
    operators.MESH_OT_add_ui_button,
    operators.MESH_OT_add_ui_scrollbar,
    operators.MESH_OT_add_ui_checkbox,
    operators.MESH_OT_add_ui_tabbed_panel,
    operators.MESH_OT_add_ui_slider,
    operators.MESH_OT_add_ui_banner,
    operators.MESH_OT_add_ui_general_panel,
    operators.MESH_OT_add_ui_combined_window,
    
    # Menu Class - FIXED: Proper registration order
    VIEW3D_MT_ui_components_menu,
    
    # Main Panel from panels.py
    panels.VIEW3D_PT_ui_components_panel,
    
    # Collapsible Individual Component Panels from panels.py
    panels.VIEW3D_PT_ui_window_panel,
    panels.VIEW3D_PT_ui_button_panel,
    panels.VIEW3D_PT_ui_checkbox_panel,
    panels.VIEW3D_PT_ui_scrollbar_panel,
    panels.VIEW3D_PT_ui_slider_panel,
    panels.VIEW3D_PT_ui_banner_panel,
    panels.VIEW3D_PT_ui_general_panel_panel,
    
    # Advanced and System Panels from panels.py
    panels.VIEW3D_PT_ui_components_advanced_panel,
    panels.VIEW3D_PT_ui_components_system_panel,
)

def menu_func(self, context):
    self.layout.separator()
    self.layout.menu("VIEW3D_MT_ui_components_menu", icon='PREFERENCES')

def register():
    """Register all classes and properties for the add-on"""
    try:
        # Register all classes in proper order
        for cls in classes:
            bpy.utils.register_class(cls)
        
        # Register property groups to scene
        bpy.types.Scene.ui_window_props = bpy.props.PointerProperty(type=properties.UIWindowProperties)
        bpy.types.Scene.ui_button_props = bpy.props.PointerProperty(type=properties.UIButtonProperties)
        bpy.types.Scene.ui_scrollbar_props = bpy.props.PointerProperty(type=properties.UIScrollbarProperties)
        bpy.types.Scene.ui_checkbox_props = bpy.props.PointerProperty(type=properties.UICheckboxProperties)
        bpy.types.Scene.ui_tabbed_panel_props = bpy.props.PointerProperty(type=properties.UITabbedPanelProperties)
        bpy.types.Scene.ui_slider_props = bpy.props.PointerProperty(type=properties.UISliderProperties)
        bpy.types.Scene.ui_banner_props = bpy.props.PointerProperty(type=properties.UIBannerProperties)
        bpy.types.Scene.ui_general_panel_props = bpy.props.PointerProperty(type=properties.UIGeneralPanelProperties)
        
        # Add to Blender menu
        bpy.types.VIEW3D_MT_mesh_add.append(menu_func)
        
        print("UI Components Add-On Successfully registered with Sidebar visibility")
        
    except Exception as e:
        # Automatically open error console for debugging if registration fails
        print(f"UI Components Add-On: Registration error - {e}")
        enable_error_console()
        raise e

def unregister():
    """Unregister all classes and clean up properties"""
    try:
        # Remove from menu
        bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
        
        # Remove property groups with proper cleanup
        del bpy.types.Scene.ui_window_props
        del bpy.types.Scene.ui_button_props
        del bpy.types.Scene.ui_scrollbar_props
        del bpy.types.Scene.ui_checkbox_props
        del bpy.types.Scene.ui_tabbed_panel_props
        del bpy.types.Scene.ui_slider_props
        del bpy.types.Scene.ui_banner_props
        del bpy.types.Scene.ui_general_panel_props
        
        # Unregister all classes in reverse order for proper cleanup
        for cls in reversed(classes):
            bpy.utils.unregister_class(cls)
            
        print("UI Components Add-On Successfully unregistered")
        
    except Exception as e:
        # Automatically open error console for debugging if unregistration fails
        print(f"UI Components Add-On: Unregistration error - {e}")
        enable_error_console()
        raise e

# Enable direct execution for testing
if __name__ == "__main__":
    register()