# Blender UI Components Add-On - Mesh Generation and Material Utilities
# Compatible with Blender 4.0+ and Windows 10 64-bit+
# Production Environment Code - Version 1.0.12

import bpy
import bmesh
from mathutils import Vector
import math
import bpy

# Mesh Generation Utility Functions
def create_rounded_rectangle(width, height, corner_radius, segments=8):
    """Create a rounded rectangle mesh with proper UV coordinates"""
    verts = []
    faces = []
    
    # Calculate actual radius to prevent overflow
    max_radius = min(width, height) * 0.5
    actual_radius = min(corner_radius, max_radius)
    
    if actual_radius <= 0.001:
        # Create simple rectangle if radius is negligible
        half_w = width * 0.5
        half_h = height * 0.5
        verts = [
            (-half_w, -half_h, 0.0),
            (half_w, -half_h, 0.0),
            (half_w, half_h, 0.0),
            (-half_w, half_h, 0.0)
        ]
        faces = [[0, 1, 2, 3]]
        return verts, faces
    
    # Calculate corner positions
    half_w = width * 0.5
    half_h = height * 0.5
    
    # Corner centers for rounded corners
    corners = [
        (half_w - actual_radius, half_h - actual_radius),    # Top right
        (-half_w + actual_radius, half_h - actual_radius),   # Top left  
        (-half_w + actual_radius, -half_h + actual_radius),  # Bottom left
        (half_w - actual_radius, -half_h + actual_radius)    # Bottom right
    ]
    
    # Generate vertices for rounded corners
    for i, (cx, cy) in enumerate(corners):
        start_angle = i * math.pi * 0.5
        for j in range(segments):
            angle = start_angle + (j * math.pi * 0.5 / segments)
            x = cx + actual_radius * math.cos(angle)
            y = cy + actual_radius * math.sin(angle)
            verts.append((x, y, 0.0))
    
    # Add center vertex for triangulation
    center_idx = len(verts)
    verts.append((0.0, 0.0, 0.0))
    
    # Create triangular faces from center
    total_corner_verts = len(corners) * segments
    for i in range(total_corner_verts):
        next_i = (i + 1) % total_corner_verts
        faces.append([center_idx, i, next_i])
    
    return verts, faces

def create_inward_border_rectangle(outer_width, outer_height, border_width, corner_radius, segments=8):
    """Create inward border rectangle mesh where border goes inward from edge"""
    verts = []
    faces = []
    
    # Calculate inner dimensions by subtracting border width from each side
    inner_width = max(0.01, outer_width - (border_width * 2))
    inner_height = max(0.01, outer_height - (border_width * 2))
    
    # Calculate actual radius to prevent overflow
    max_outer_radius = min(outer_width, outer_height) * 0.5
    max_inner_radius = min(inner_width, inner_height) * 0.5
    actual_outer_radius = min(corner_radius, max_outer_radius)
    actual_inner_radius = min(corner_radius * 0.7, max_inner_radius)
    
    # Create outer boundary vertices
    outer_verts, _ = create_rounded_rectangle(outer_width, outer_height, actual_outer_radius, segments)
    
    # Create inner boundary vertices (hole in the center)
    inner_verts, _ = create_rounded_rectangle(inner_width, inner_height, actual_inner_radius, segments)
    
    # Combine vertices (outer first, then inner)
    verts.extend(outer_verts[:-1])  # Exclude center vertex from outer
    inner_start_idx = len(verts)
    verts.extend(inner_verts[:-1])  # Exclude center vertex from inner
    
    # Create border faces between outer and inner boundaries
    outer_count = len(outer_verts) - 1  # Exclude center
    inner_count = len(inner_verts) - 1  # Exclude center
    
    # Connect outer and inner boundaries with quad faces
    for i in range(outer_count):
        next_outer = (i + 1) % outer_count
        # Map inner indices proportionally
        inner_i = int((i * inner_count) / outer_count)
        next_inner_i = int((next_outer * inner_count) / outer_count)
        
        # Create quad face connecting outer to inner
        faces.append([
            i,                                    # Outer vertex
            next_outer,                          # Next outer vertex
            inner_start_idx + next_inner_i,      # Corresponding inner vertex
            inner_start_idx + inner_i            # Previous inner vertex
        ])
    
    return verts, faces

def create_circle_mesh(radius, segments=16):
    """Create circular mesh for circular components"""
    verts = []
    faces = []
    
    # Center vertex
    verts.append((0.0, 0.0, 0.0))
    
    # Perimeter vertices
    for i in range(segments):
        angle = (i * 2.0 * math.pi) / segments
        x = radius * math.cos(angle)
        y = radius * math.sin(angle)
        verts.append((x, y, 0.0))
    
    # Create triangular faces from center
    for i in range(segments):
        next_i = (i + 1) % segments + 1
        faces.append([0, i + 1, next_i])
    
    return verts, faces

def create_circle_border_mesh(outer_radius, inner_radius, segments=16):
    """Create circular border mesh (ring shape)"""
    verts = []
    faces = []
    
    # Outer circle vertices
    for i in range(segments):
        angle = (i * 2.0 * math.pi) / segments
        x = outer_radius * math.cos(angle)
        y = outer_radius * math.sin(angle)
        verts.append((x, y, 0.0))
    
    # Inner circle vertices
    for i in range(segments):
        angle = (i * 2.0 * math.pi) / segments
        x = inner_radius * math.cos(angle)
        y = inner_radius * math.sin(angle)
        verts.append((x, y, 0.0))
    
    # Create quad faces between outer and inner circles
    for i in range(segments):
        next_i = (i + 1) % segments
        # Create quad connecting outer and inner circles
        faces.append([
            i,                    # Outer vertex
            next_i,              # Next outer vertex
            next_i + segments,   # Corresponding inner vertex
            i + segments         # Previous inner vertex
        ])
    
    return verts, faces

def create_arrow_mesh(size, direction='UP'):
    """Create arrow mesh for scrollbar components"""
    half_size = size * 0.5
    
    if direction == 'UP':
        verts = [
            (0.0, half_size, 0.0),
            (-half_size, -half_size, 0.0),
            (half_size, -half_size, 0.0)
        ]
    elif direction == 'DOWN':
        verts = [
            (0.0, -half_size, 0.0),
            (-half_size, half_size, 0.0),
            (half_size, half_size, 0.0)
        ]
    elif direction == 'LEFT':
        verts = [
            (-half_size, 0.0, 0.0),
            (half_size, half_size, 0.0),
            (half_size, -half_size, 0.0)
        ]
    elif direction == 'RIGHT':
        verts = [
            (half_size, 0.0, 0.0),
            (-half_size, half_size, 0.0),
            (-half_size, -half_size, 0.0)
        ]
    
    faces = [[0, 1, 2]]
    return verts, faces

def create_mesh_with_uvs(context, name, verts, faces):
    """Create mesh object with proper UV coordinates for game engine export"""
    # Create new mesh
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    
    # Create UV layer if mesh has faces
    if len(faces) > 0:
        mesh.uv_layers.new(name="UVMap")
        uv_layer = mesh.uv_layers.active
        
        # Calculate bounds for UV normalization
        if len(verts) > 0:
            xs = [v[0] for v in verts]
            ys = [v[1] for v in verts]
            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
            
            # Prevent division by zero
            width = max_x - min_x if max_x != min_x else 1.0
            height = max_y - min_y if max_y != min_y else 1.0
            
            # Apply UV coordinates to each face loop
            for face in mesh.polygons:
                for loop_idx in face.loop_indices:
                    loop = mesh.loops[loop_idx]
                    vert = mesh.vertices[loop.vertex_index]
                    
                    # Normalize coordinates to 0-1 UV space
                    u = (vert.co.x - min_x) / width
                    v = (vert.co.y - min_y) / height
                    
                    uv_layer.data[loop_idx].uv = (u, v)
    
    # Create object and link to collection
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    
    return obj

def create_rounded_button_mesh(context, name, width, height, depth, corner_radius, bevel_segments=8):
    """Create properly rounded button mesh using bmesh for precise corner rounding"""
    # Create new bmesh instance
    bm = bmesh.new()
    
    # Create base cube geometry
    bmesh.ops.create_cube(bm, size=1.0)
    
    # Scale to button dimensions
    bmesh.ops.scale(bm, vec=(width, height, depth), verts=bm.verts)
    
    # Apply corner rounding if radius is significant
    if corner_radius > 0.001:
        # Select edges that need beveling (not the depth edges)
        edges_to_bevel = []
        for edge in bm.edges:
            # Check if edge is horizontal or vertical (not depth-related)
            v1, v2 = edge.verts
            # Calculate edge direction
            edge_vector = v2.co - v1.co
            
            # Check if edge is primarily in X or Y direction (not Z)
            if abs(edge_vector.z) < 0.001:  # Edge is not in Z direction
                edges_to_bevel.append(edge)
        
        # Apply bevel operation for corner rounding
        if edges_to_bevel:
            bmesh.ops.bevel(
                bm, 
                geom=edges_to_bevel, 
                offset=corner_radius, 
                segments=bevel_segments,
                profile=0.5,
                offset_type='OFFSET'
            )
    
    # Create mesh from bmesh
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    
    # Update mesh and create UV mapping
    mesh.update()
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    
    # Create object and link to collection
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    
    return obj

def create_slider_track_mesh(context, name, length, width, orientation='HORIZONTAL'):
    """Create slider track mesh using bmesh for proper geometry"""
    # Create new bmesh instance
    bm = bmesh.new()
    
    # Create base cube for track
    bmesh.ops.create_cube(bm, size=1.0)
    
    # Scale based on orientation
    if orientation == 'HORIZONTAL':
        track_scale = (length, width, width * 0.5)
    else:
        track_scale = (width, length, width * 0.5)
    
    bmesh.ops.scale(bm, vec=track_scale, verts=bm.verts)
    
    # Apply slight rounding to track edges
    bevel_edges = [e for e in bm.edges if abs(e.calc_length() - width) > 0.001]
    if bevel_edges:
        bmesh.ops.bevel(
            bm,
            geom=bevel_edges,
            offset=width * 0.1,
            segments=4
        )
    
    # Create mesh from bmesh
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    
    # Update mesh and create UV mapping
    mesh.update()
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    
    # Create object and link to collection
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    
    return obj

def create_slider_knob_mesh(context, name, knob_size):
    """Create slider knob mesh using sphere generation for proper 3D appearance"""
    # Create new bmesh instance
    bm = bmesh.new()
    
    # CRITICAL FIX: Use create_icosphere instead of create_uv_sphere for Blender 4+ compatibility
    bmesh.ops.create_icosphere(bm, subdivisions=2, radius=knob_size * 0.5)
    
    # Scale knob for proper proportions (slightly flattened)
    bmesh.ops.scale(bm, vec=(1.0, 1.0, 0.6), verts=bm.verts)
    
    # Create mesh from bmesh
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    
    # Update mesh and create UV mapping
    mesh.update()
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    
    # Create object and link to collection
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    
    return obj

# NEW: Enhanced slider track mesh with embossed appearance and curved corners
def create_enhanced_slider_track_mesh(context, name, length, width, orientation='HORIZONTAL', 
                                    corner_radius=0.02, embossed=True, emboss_depth=0.005):
    """Create enhanced slider track mesh with embossed appearance and curved corners"""
    # Create new bmesh instance
    bm = bmesh.new()
    
    # Create base cube for track
    bmesh.ops.create_cube(bm, size=1.0)
    
    # Scale based on orientation
    if orientation == 'HORIZONTAL':
        track_scale = (length, width, width * 0.5)
    else:
        track_scale = (width, length, width * 0.5)
    
    bmesh.ops.scale(bm, vec=track_scale, verts=bm.verts)
    
    # Apply corner rounding if radius is significant
    if corner_radius > 0.001:
        # Select appropriate edges for corner rounding
        edges_to_bevel = []
        for edge in bm.edges:
            v1, v2 = edge.verts
            edge_vector = v2.co - v1.co
            
            # Select edges that are not primarily in Z direction for corner rounding
            if abs(edge_vector.z) < width * 0.3:
                edges_to_bevel.append(edge)
        
        if edges_to_bevel:
            bmesh.ops.bevel(
                bm,
                geom=edges_to_bevel,
                offset=corner_radius,
                segments=6,
                profile=0.5
            )
    
    # Apply embossed effect by creating inset depression
    if embossed and emboss_depth > 0.001:
        # Select top faces for embossing
        top_faces = [f for f in bm.faces if f.normal.z > 0.5]
        
        if top_faces:
            # Create inset for embossed track depression using correct BMesh operation
            bmesh.ops.inset_individual(
                bm,
                faces=top_faces,
                thickness=width * 0.15,
                depth=emboss_depth,
                use_even_offset=True
            )
    
    # Create mesh from bmesh
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    
    # Update mesh and create UV mapping
    mesh.update()
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    
    # Create object and link to collection
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    
    return obj

# NEW: Enhanced scrollbar track mesh with embossed appearance and curved corners
def create_enhanced_scrollbar_track_mesh(context, name, length, width, orientation='VERTICAL',
                                       corner_radius=0.02, embossed=True, emboss_depth=0.005):
    """Create enhanced scrollbar track mesh with embossed appearance and curved corners"""
    # Create new bmesh instance
    bm = bmesh.new()
    
    # Create base cube for track
    bmesh.ops.create_cube(bm, size=1.0)
    
    # Scale based on orientation
    if orientation == 'HORIZONTAL':
        track_scale = (length, width, width * 0.8)
    else:
        track_scale = (width, length, width * 0.8)
    
    bmesh.ops.scale(bm, vec=track_scale, verts=bm.verts)
    
    # Apply corner rounding if radius is significant
    if corner_radius > 0.001:
        # Select appropriate edges for corner rounding
        edges_to_bevel = []
        for edge in bm.edges:
            v1, v2 = edge.verts
            edge_vector = v2.co - v1.co
            
            # Select edges that are not primarily in Z direction for corner rounding
            if abs(edge_vector.z) < width * 0.4:
                edges_to_bevel.append(edge)
        
        if edges_to_bevel:
            bmesh.ops.bevel(
                bm,
                geom=edges_to_bevel,
                offset=corner_radius,
                segments=6,
                profile=0.5
            )
    
    # Apply embossed effect by creating inset depression
    if embossed and emboss_depth > 0.001:
        # Select top faces for embossing
        top_faces = [f for f in bm.faces if f.normal.z > 0.5]
        
        if top_faces:
            # Create inset for embossed scrollbar track depression using correct BMesh operation
            bmesh.ops.inset_individual(
                bm,
                faces=top_faces,
                thickness=width * 0.1,
                depth=emboss_depth,
                use_even_offset=True
            )
    
    # Create mesh from bmesh
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    
    # Update mesh and create UV mapping
    mesh.update()
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    
    # Create object and link to collection
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    
    return obj

# NEW: Scrollbar track knob mesh generation - CRITICAL VISIBILITY FIX
def create_scrollbar_track_knob_mesh(context, name, knob_length, width, orientation='VERTICAL'):
    """Create scrollbar track knob mesh for representing content size with clear visual separation"""
    # Create new bmesh instance
    bm = bmesh.new()
    
    # Create base cube for track knob
    bmesh.ops.create_cube(bm, size=1.0)
    
    # CRITICAL FIX: Scale based on orientation and knob size with much narrower dimensions for clear separation
    if orientation == 'HORIZONTAL':
        knob_scale = (knob_length, width * 0.5, width * 0.25)  # FIXED: Much narrower for clear visual separation
    else:
        knob_scale = (width * 0.5, knob_length, width * 0.25)  # FIXED: Much narrower for clear visual separation
    
    bmesh.ops.scale(bm, vec=knob_scale, verts=bm.verts)
    
    # Apply rounding to make knob appear more polished
    edges_to_bevel = []
    for edge in bm.edges:
        v1, v2 = edge.verts
        edge_vector = v2.co - v1.co
        
        # Apply slight beveling to all edges for smooth appearance
        edges_to_bevel.append(edge)
    
    if edges_to_bevel:
        bmesh.ops.bevel(
            bm,
            geom=edges_to_bevel,
            offset=width * 0.06,  # Reduced bevel for better proportion
            segments=4,
            profile=0.5
        )
    
    # Create mesh from bmesh
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    
    # Update mesh and create UV mapping
    mesh.update()
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    
    # Create object and link to collection
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    
    return obj

def create_material_with_transparency(name, base_color=(0.8, 0.8, 0.8, 1.0), transparency=0.0):
    """Create material with specified base color and transparency for component styling"""
    # Check if material already exists
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    
    # Clear default nodes
    mat.node_tree.nodes.clear()
    
    # Add Principled BSDF and Material Output nodes
    bsdf = mat.node_tree.nodes.new(type="ShaderNodeBsdfPrincipled")
    output = mat.node_tree.nodes.new(type="ShaderNodeOutputMaterial")
    
    # Set base color
    bsdf.inputs[0].default_value = base_color
    
    # Set transparency if specified
    if transparency > 0.0:
        # Set material to use alpha blend mode for transparency
        mat.blend_method = 'BLEND'
        mat.show_transparent_back = False
        
        # Set alpha value in the base color
        adjusted_color = list(base_color)
        adjusted_color[3] = 1.0 - transparency  # Convert transparency to alpha
        bsdf.inputs[0].default_value = adjusted_color
        
        # Set transmission for glass-like transparency
        bsdf.inputs[15].default_value = transparency  # Transmission
    
    # Connect nodes
    mat.node_tree.links.new(bsdf.outputs[0], output.inputs[0])
    
    return mat

def get_or_create_material(material_enum, material_name, base_color, transparency):
    """Get existing material or create new one based on enum selection"""
    if material_enum == 'CREATE_NEW':
        return create_material_with_transparency(material_name, base_color, transparency)
    else:
        # Use existing material
        if material_enum in bpy.data.materials:
            return bpy.data.materials[material_enum]
        else:
            # Fallback to creating new if selected material doesn't exist
            return create_material_with_transparency(material_name, base_color, transparency)

def create_material(name, base_color=(0.8, 0.8, 0.8, 1.0)):
    """Legacy create material function for backward compatibility"""
    return create_material_with_transparency(name, base_color, 0.0)

# Focus UI tab function with correct category name
def focus_ui_tab(tab_name="UI Components"):
    """Opens the sidebar and focuses the given tab name - FIXED for v0.0.10"""
    # Find the 3D Viewport area
    area = next((a for a in bpy.context.screen.areas if a.type == 'VIEW_3D'), None)
    if not area:
        return

    # Set the correct tab category for all 3D Viewport spaces
    for space in area.spaces:
        if space.type == 'VIEW_3D':
            space.show_region_ui = True  # Ensure sidebar is visible
            # Use correct tab category name
            if hasattr(space, 'ui_tabs_category'):
                space.ui_tabs_category = tab_name

    # Ensure the UI region is visible
    for region in area.regions:
        if region.type == 'UI':
            override = bpy.context.copy()
            override['area'] = area
            override['region'] = region
            try:
                # Force sidebar to be visible if it's not already
                if not region.width > 1:
                    bpy.ops.wm.context_toggle(override, data_path="space_data.show_region_ui")
            except:
                pass  # Safe fail if already open or unavailable
            break
            
def create_component_group(context, group_name, main_object, sub_objects=None):
    """Create a grouped component system with collection and parent-child relationships"""
    if sub_objects is None:
        sub_objects = []
    
    # Create new collection for the component group
    group_collection = bpy.data.collections.new(group_name)
    context.scene.collection.children.link(group_collection)
    
    # Create empty object as group controller
    empty_controller = bpy.data.objects.new(f"{group_name}_Controller", None)
    empty_controller.empty_display_type = 'PLAIN_AXES'
    empty_controller.empty_display_size = 0.5
    group_collection.objects.link(empty_controller)
    
    # Move main object to group collection and set as child of controller
    if main_object.name in context.scene.collection.objects:
        context.scene.collection.objects.unlink(main_object)
    group_collection.objects.link(main_object)
    main_object.parent = empty_controller
    
    # Move sub-objects to group collection and set as children of main object
    for sub_obj in sub_objects:
        if sub_obj.name in context.scene.collection.objects:
            context.scene.collection.objects.unlink(sub_obj)
        group_collection.objects.link(sub_obj)
        sub_obj.parent = main_object
    
    # Set the empty controller as active object
    context.view_layer.objects.active = empty_controller
    
    return empty_controller, group_collection
