# Blender UI Components Add-On - Property Group Definitions
# Compatible with Blender 4.0+ and Windows 10 64-bit+
# Production Environment Code - Version 1.0.12

import bpy
from bpy.props import FloatProperty, IntProperty, BoolProperty, EnumProperty, StringProperty
from bpy.types import PropertyGroup

# Material selection helper function
def get_material_items(self, context):
    """Get list of existing materials for dropdown selection"""
    items = [('CREATE_NEW', "Create New Material", "Create a new material")]
    
    # Add existing materials to the list
    for mat in bpy.data.materials:
        items.append((mat.name, mat.name, f"Use existing material: {mat.name}"))
    
    return items

# Property Groups for Component Settings
class UIWindowProperties(PropertyGroup):
    """Properties for main window panel configuration with enhanced material options"""
    width: FloatProperty(
        name="Width",
        description="Width of the main window panel",
        default=4.0,
        min=0.5,
        max=20.0
    )
    height: FloatProperty(
        name="Height", 
        description="Height of the main window panel",
        default=3.0,
        min=0.5,
        max=20.0
    )
    corner_radius: FloatProperty(
        name="Corner Radius",
        description="Radius for curved corners of the window",
        default=0.1,
        min=0.0,
        max=1.0
    )
    has_titlebar: BoolProperty(
        name="Include Titlebar",
        description="Add a titlebar to the window",
        default=True
    )
    titlebar_height: FloatProperty(
        name="Titlebar Height",
        description="Height of the titlebar section",
        default=0.4,
        min=0.1,
        max=2.0
    )
    close_button: BoolProperty(
        name="Close Button",
        description="Add circular close button to titlebar",
        default=True
    )
    minimize_button: BoolProperty(
        name="Minimize Button", 
        description="Add circular minimize button to titlebar",
        default=True
    )
    
    # Main Window Material Properties
    main_material: EnumProperty(
        name="Main Material",
        description="Material for the main window",
        items=get_material_items,
        default=0
    )
    main_material_name: StringProperty(
        name="Material Name",
        description="Name for new main window material",
        default="UI_Window_Material"
    )
    main_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for main window material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Titlebar Material Properties
    titlebar_material: EnumProperty(
        name="Titlebar Material",
        description="Material for the titlebar",
        items=get_material_items,
        default=0
    )
    titlebar_material_name: StringProperty(
        name="Material Name",
        description="Name for new titlebar material",
        default="UI_Titlebar_Material"
    )
    titlebar_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for titlebar material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Close Button Material Properties
    close_button_material: EnumProperty(
        name="Close Button Material",
        description="Material for the close button",
        items=get_material_items,
        default=0
    )
    close_button_material_name: StringProperty(
        name="Material Name",
        description="Name for new close button material",
        default="UI_CloseButton_Material"
    )
    close_button_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for close button material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Minimize Button Material Properties
    minimize_button_material: EnumProperty(
        name="Minimize Button Material",
        description="Material for the minimize button",
        items=get_material_items,
        default=0
    )
    minimize_button_material_name: StringProperty(
        name="Material Name",
        description="Name for new minimize button material",
        default="UI_MinimizeButton_Material"
    )
    minimize_button_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for minimize button material",
        default=0.0,
        min=0.0,
        max=1.0
    )

class UIButtonProperties(PropertyGroup):
    """Properties for button component configuration with enhanced material options"""
    width: FloatProperty(
        name="Width",
        description="Width of the button",
        default=1.5,
        min=0.2,
        max=10.0
    )
    height: FloatProperty(
        name="Height",
        description="Height of the button", 
        default=0.5,
        min=0.1,
        max=5.0
    )
    corner_radius: FloatProperty(
        name="Corner Radius",
        description="Radius for curved corners of the button",
        default=0.05,
        min=0.0,
        max=0.5
    )
    depth: FloatProperty(
        name="Depth",
        description="Depth of the button for 3D appearance",
        default=0.1,
        min=0.01,
        max=1.0
    )
    bevel_segments: IntProperty(
        name="Bevel Segments",
        description="Number of segments for button corner beveling",
        default=8,
        min=1,
        max=32
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of the button border",
        default=0.02,
        min=0.0,
        max=0.2
    )
    
    # Main Material Properties
    main_material: EnumProperty(
        name="Main Material",
        description="Material for the main button",
        items=get_material_items,
        default=0
    )
    main_material_name: StringProperty(
        name="Material Name",
        description="Name for new main button material",
        default="UI_Button_Material"
    )
    main_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for main button material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Border Material Properties
    border_material: EnumProperty(
        name="Border Material",
        description="Material for the button border",
        items=get_material_items,
        default=0
    )
    border_material_name: StringProperty(
        name="Material Name",
        description="Name for new border material",
        default="UI_ButtonBorder_Material"
    )
    border_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for border material",
        default=0.0,
        min=0.0,
        max=1.0
    )

class UIScrollbarProperties(PropertyGroup):
    """Properties for scrollbar component configuration with enhanced features"""
    orientation: EnumProperty(
        name="Orientation",
        description="Scrollbar orientation",
        items=[
            ('HORIZONTAL', "Horizontal", "Horizontal scrollbar"),
            ('VERTICAL', "Vertical", "Vertical scrollbar")
        ],
        default='VERTICAL'
    )
    length: FloatProperty(
        name="Length",
        description="Length of the scrollbar",
        default=3.0,
        min=0.5,
        max=20.0
    )
    width: FloatProperty(
        name="Width",
        description="Width of the scrollbar track",
        default=0.2,
        min=0.05,
        max=1.0
    )
    arrow_size: FloatProperty(
        name="Arrow Size",
        description="Size of the directional arrows",
        default=0.15,
        min=0.05,
        max=0.5
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of the scrollbar borders",
        default=0.02,
        min=0.0,
        max=0.1
    )
    
    # Enhanced Appearance Properties
    corner_radius: FloatProperty(
        name="Corner Radius",
        description="Radius for curved corners of the scrollbar",
        default=0.02,
        min=0.0,
        max=0.1
    )
    embossed: BoolProperty(
        name="Embossed Track",
        description="Create embossed appearance for scrollbar track",
        default=True
    )
    emboss_depth: FloatProperty(
        name="Emboss Depth",
        description="Depth of the embossed track depression",
        default=0.005,
        min=0.001,
        max=0.05
    )
    
    # Track Knob Properties
    has_track_knob: BoolProperty(
        name="Track Knob",
        description="Add track knob to represent content size",
        default=True
    )
    track_knob_size: FloatProperty(
        name="Track Knob Size",
        description="Size of the track knob relative to track length",
        default=0.3,
        min=0.1,
        max=0.8
    )
    track_knob_position: FloatProperty(
        name="Track Knob Position",
        description="Position of the track knob along the track",
        default=0.5,
        min=0.0,
        max=1.0
    )
    
    # Track Material Properties
    track_material: EnumProperty(
        name="Track Material",
        description="Material for the scrollbar track",
        items=get_material_items,
        default=0
    )
    track_material_name: StringProperty(
        name="Material Name",
        description="Name for new track material",
        default="UI_ScrollbarTrack_Material"
    )
    track_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for track material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Arrow Material Properties
    arrow_material: EnumProperty(
        name="Arrow Material",
        description="Material for the scrollbar arrows",
        items=get_material_items,
        default=0
    )
    arrow_material_name: StringProperty(
        name="Material Name",
        description="Name for new arrow material",
        default="UI_ScrollbarArrow_Material"
    )
    arrow_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for arrow material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Track Knob Material Properties
    track_knob_material: EnumProperty(
        name="Track Knob Material",
        description="Material for the track knob",
        items=get_material_items,
        default=0
    )
    track_knob_material_name: StringProperty(
        name="Material Name",
        description="Name for new track knob material",
        default="UI_ScrollbarKnob_Material"
    )
    track_knob_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for track knob material",
        default=0.0,
        min=0.0,
        max=1.0
    )

class UICheckboxProperties(PropertyGroup):
    """Properties for checkbox component configuration with enhanced material options"""
    shape_type: EnumProperty(
        name="Shape",
        description="Checkbox shape type",
        items=[
            ('SQUARE', "Square", "Square checkbox"),
            ('CIRCULAR', "Circular", "Circular checkbox")
        ],
        default='SQUARE'
    )
    size: FloatProperty(
        name="Size",
        description="Size of the checkbox",
        default=0.3,
        min=0.1,
        max=2.0
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of the checkbox border",
        default=0.02,
        min=0.0,
        max=0.1
    )
    is_checked: BoolProperty(
        name="Checked State",
        description="Create checkbox in checked state with fill color",
        default=False
    )
    
    # Main Material Properties
    main_material: EnumProperty(
        name="Main Material",
        description="Material for the main checkbox",
        items=get_material_items,
        default=0
    )
    main_material_name: StringProperty(
        name="Material Name",
        description="Name for new main checkbox material",
        default="UI_Checkbox_Material"
    )
    main_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for main checkbox material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Border Material Properties
    border_material: EnumProperty(
        name="Border Material",
        description="Material for the checkbox border",
        items=get_material_items,
        default=0
    )
    border_material_name: StringProperty(
        name="Material Name",
        description="Name for new border material",
        default="UI_CheckboxBorder_Material"
    )
    border_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for border material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Checked State Material Properties
    checked_material: EnumProperty(
        name="Checked Material",
        description="Material for the checked state indicator",
        items=get_material_items,
        default=0
    )
    checked_material_name: StringProperty(
        name="Material Name",
        description="Name for new checked state material",
        default="UI_CheckboxChecked_Material"
    )
    checked_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for checked state material",
        default=0.0,
        min=0.0,
        max=1.0
    )

class UITabbedPanelProperties(PropertyGroup):
    """Properties for tabbed panel component configuration with enhanced material options"""
    panel_width: FloatProperty(
        name="Panel Width",
        description="Width of the content panel",
        default=4.0,
        min=1.0,
        max=20.0
    )
    panel_height: FloatProperty(
        name="Panel Height", 
        description="Height of the content panel",
        default=3.0,
        min=1.0,
        max=20.0
    )
    tab_height: FloatProperty(
        name="Tab Height",
        description="Height of the tab headers",
        default=0.4,
        min=0.1,
        max=2.0
    )
    tab_count: IntProperty(
        name="Number of Tabs",
        description="Number of tabs to create",
        default=3,
        min=1,
        max=10
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of the panel borders",
        default=0.02,
        min=0.0,
        max=0.2
    )
    
    # Content Material Properties
    content_material: EnumProperty(
        name="Content Material",
        description="Material for the content panel",
        items=get_material_items,
        default=0
    )
    content_material_name: StringProperty(
        name="Material Name",
        description="Name for new content material",
        default="UI_TabbedPanelContent_Material"
    )
    content_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for content material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Active Tab Material Properties
    active_tab_material: EnumProperty(
        name="Active Tab Material",
        description="Material for the active tab",
        items=get_material_items,
        default=0
    )
    active_tab_material_name: StringProperty(
        name="Material Name",
        description="Name for new active tab material",
        default="UI_TabActive_Material"
    )
    active_tab_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for active tab material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Inactive Tab Material Properties
    inactive_tab_material: EnumProperty(
        name="Inactive Tab Material",
        description="Material for inactive tabs",
        items=get_material_items,
        default=0
    )
    inactive_tab_material_name: StringProperty(
        name="Material Name",
        description="Name for new inactive tab material",
        default="UI_TabInactive_Material"
    )
    inactive_tab_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for inactive tab material",
        default=0.0,
        min=0.0,
        max=1.0
    )

class UISliderProperties(PropertyGroup):
    """Properties for slider component configuration with enhanced features"""
    orientation: EnumProperty(
        name="Orientation",
        description="Slider orientation",
        items=[
            ('HORIZONTAL', "Horizontal", "Horizontal slider"),
            ('VERTICAL', "Vertical", "Vertical slider")
        ],
        default='HORIZONTAL'
    )
    length: FloatProperty(
        name="Length",
        description="Length of the slider track",
        default=2.0,
        min=0.5,
        max=10.0
    )
    track_width: FloatProperty(
        name="Track Width",
        description="Width of the slider track",
        default=0.1,
        min=0.02,
        max=0.5
    )
    knob_size: FloatProperty(
        name="Knob Size",
        description="Size of the slider knob",
        default=0.2,
        min=0.05,
        max=1.0
    )
    knob_position: FloatProperty(
        name="Knob Position",
        description="Position of the knob along the track",
        default=0.5,
        min=0.0,
        max=1.0
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of the slider borders",
        default=0.02,
        min=0.0,
        max=0.1
    )
    
    # Enhanced Appearance Properties
    corner_radius: FloatProperty(
        name="Corner Radius",
        description="Radius for curved corners of the slider",
        default=0.02,
        min=0.0,
        max=0.1
    )
    embossed: BoolProperty(
        name="Embossed Track",
        description="Create embossed appearance for slider track",
        default=True
    )
    emboss_depth: FloatProperty(
        name="Emboss Depth",
        description="Depth of the embossed track depression",
        default=0.005,
        min=0.001,
        max=0.05
    )
    
    # Track Material Properties
    track_material: EnumProperty(
        name="Track Material",
        description="Material for the slider track",
        items=get_material_items,
        default=0
    )
    track_material_name: StringProperty(
        name="Material Name",
        description="Name for new track material",
        default="UI_SliderTrack_Material"
    )
    track_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for track material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Knob Material Properties
    knob_material: EnumProperty(
        name="Knob Material",
        description="Material for the slider knob",
        items=get_material_items,
        default=0
    )
    knob_material_name: StringProperty(
        name="Material Name",
        description="Name for new knob material",
        default="UI_SliderKnob_Material"
    )
    knob_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for knob material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Border Material Properties
    border_material: EnumProperty(
        name="Border Material",
        description="Material for the slider border",
        items=get_material_items,
        default=0
    )
    border_material_name: StringProperty(
        name="Material Name",
        description="Name for new border material",
        default="UI_SliderBorder_Material"
    )
    border_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for border material",
        default=0.0,
        min=0.0,
        max=1.0
    )

class UIBannerProperties(PropertyGroup):
    """Properties for banner component configuration with enhanced material options"""
    width: FloatProperty(
        name="Width",
        description="Width of the banner",
        default=6.0,
        min=1.0,
        max=30.0
    )
    height: FloatProperty(
        name="Height",
        description="Height of the banner",
        default=0.8,
        min=0.2,
        max=5.0
    )
    corner_radius: FloatProperty(
        name="Corner Radius",
        description="Radius for curved corners of the banner",
        default=0.05,
        min=0.0,
        max=0.5
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of the banner border",
        default=0.02,
        min=0.0,
        max=0.2
    )
    
    # Main Material Properties
    main_material: EnumProperty(
        name="Main Material",
        description="Material for the main banner",
        items=get_material_items,
        default=0
    )
    main_material_name: StringProperty(
        name="Material Name",
        description="Name for new main banner material",
        default="UI_Banner_Material"
    )
    main_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for main banner material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Border Material Properties
    border_material: EnumProperty(
        name="Border Material",
        description="Material for the banner border",
        items=get_material_items,
        default=0
    )
    border_material_name: StringProperty(
        name="Material Name",
        description="Name for new border material",
        default="UI_BannerBorder_Material"
    )
    border_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for border material",
        default=0.0,
        min=0.0,
        max=1.0
    )

class UIGeneralPanelProperties(PropertyGroup):
    """Properties for general panel component configuration with enhanced material options"""
    width: FloatProperty(
        name="Width",
        description="Width of the panel",
        default=3.0,
        min=0.5,
        max=20.0
    )
    height: FloatProperty(
        name="Height",
        description="Height of the panel",
        default=2.0,
        min=0.5,
        max=20.0
    )
    corner_radius: FloatProperty(
        name="Corner Radius",
        description="Radius for curved corners of the panel",
        default=0.1,
        min=0.0,
        max=1.0
    )
    border_width: FloatProperty(
        name="Border Width",
        description="Width of the panel borders",
        default=0.05,
        min=0.0,
        max=0.5
    )
    
    # Main Material Properties
    main_material: EnumProperty(
        name="Main Material",
        description="Material for the main panel",
        items=get_material_items,
        default=0
    )
    main_material_name: StringProperty(
        name="Material Name",
        description="Name for new main panel material",
        default="UI_GeneralPanel_Material"
    )
    main_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for main panel material",
        default=0.0,
        min=0.0,
        max=1.0
    )
    
    # Border Material Properties
    border_material: EnumProperty(
        name="Border Material",
        description="Material for the panel border",
        items=get_material_items,
        default=0
    )
    border_material_name: StringProperty(
        name="Material Name",
        description="Name for new border material",
        default="UI_GeneralPanelBorder_Material"
    )
    border_transparency: FloatProperty(
        name="Transparency",
        description="Transparency level for border material",
        default=0.0,
        min=0.0,
        max=1.0
    )