# Blender UI Components Add-On - UI Panels for Blender Interface
# Compatible with Blender 4.0+ and Windows 10 64-bit+
# Production Environment Code - Version 1.0.12

import bpy
from bpy.types import Panel

# Main UI Panel Class for Blender Interface
class VIEW3D_PT_ui_components_panel(Panel):
    """Main panel for UI Components creation in 3D Viewport"""
    bl_label = "UI Components Builder"
    bl_idname = "VIEW3D_PT_ui_components_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Main header
        layout.label(text="Professional UI Component Builder", icon='MESH_CUBE')

        # Error Console Access for Debugging
        error_box = layout.box()
        error_box.label(text="Debug Console Access", icon='CONSOLE')
        error_box.operator("wm.console_toggle", text="Toggle System Console", icon='CONSOLE')

        # Quick Create Buttons Section
        quick_box = layout.box()
        quick_box.label(text="Quick Create", icon='ADD')
        
        # Window Component Button
        window_box = quick_box.box()
        window_box.label(text="Window", icon='WINDOW')
        window_box.operator("mesh.add_ui_window", text="Create Window", icon='ADD')

        # Button Component Button
        button_box = quick_box.box()
        button_box.label(text="Button", icon='MESH_CUBE')
        button_box.operator("mesh.add_ui_button", text="Create Button", icon='ADD')

        # Checkbox Component Button
        checkbox_box = quick_box.box()
        checkbox_box.label(text="Checkbox", icon='CHECKBOX_HLT')
        checkbox_box.operator("mesh.add_ui_checkbox", text="Create Checkbox", icon='ADD')

        # Scrollbar Component Button
        scroller_box = quick_box.box()
        scroller_box.label(text="Scrollbar", icon='SCROLL_LIST')
        scroller_box.operator("mesh.add_ui_scrollbar", text="Create Scrollbar", icon='ADD')

        # Slider Component Button
        slider_box = quick_box.box()
        slider_box.label(text="Slider", icon='DRIVER')
        slider_box.operator("mesh.add_ui_slider", text="Create Slider", icon='ADD')

        # Banner Component Button
        banner_box = quick_box.box()
        banner_box.label(text="Banner", icon='SEQUENCE_COLOR_01')
        banner_box.operator("mesh.add_ui_banner", text="Create Banner", icon='ADD')

        # General Panel Component Button
        general_box = quick_box.box()
        general_box.label(text="General Panel", icon='MESH_PLANE')
        general_box.operator("mesh.add_ui_general_panel", text="Create General Panel", icon='ADD')

        # Combined Window System Button
        combined_box = layout.box()
        combined_box.label(text="Complete System", icon='WORKSPACE')
        combined_box.operator("mesh.add_ui_combined_window", text="Create Complete System", icon='SCENE')
        layout.separator()

# Collapsible Window Panel Section
class VIEW3D_PT_ui_window_panel(Panel):
    """Collapsible Window Panel Section"""
    bl_label = "Main Window Panel"
    bl_idname = "VIEW3D_PT_ui_window_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        window_props = scene.ui_window_props
        layout.prop(window_props, "width")
        layout.prop(window_props, "height")
        layout.prop(window_props, "corner_radius")
        
        # Main Window Material Properties
        materials_box = layout.box()
        materials_box.label(text="Main Window Material", icon='MATERIAL')
        materials_box.prop(window_props, "main_material")
        if window_props.main_material == 'CREATE_NEW':
            materials_box.prop(window_props, "main_material_name")
        materials_box.prop(window_props, "main_transparency")
        
        layout.separator()
        layout.prop(window_props, "has_titlebar")
        
        if window_props.has_titlebar:
            layout.prop(window_props, "titlebar_height")
            
            # Titlebar Material Properties
            titlebar_materials_box = layout.box()
            titlebar_materials_box.label(text="Titlebar Material", icon='MATERIAL')
            titlebar_materials_box.prop(window_props, "titlebar_material")
            if window_props.titlebar_material == 'CREATE_NEW':
                titlebar_materials_box.prop(window_props, "titlebar_material_name")
            titlebar_materials_box.prop(window_props, "titlebar_transparency")
            
            row = layout.row()
            row.prop(window_props, "close_button")
            row.prop(window_props, "minimize_button")
            
            # Close Button Material Properties
            if window_props.close_button:
                close_materials_box = layout.box()
                close_materials_box.label(text="Close Button Material", icon='MATERIAL')
                close_materials_box.prop(window_props, "close_button_material")
                if window_props.close_button_material == 'CREATE_NEW':
                    close_materials_box.prop(window_props, "close_button_material_name")
                close_materials_box.prop(window_props, "close_button_transparency")
            
            # Minimize Button Material Properties
            if window_props.minimize_button:
                min_materials_box = layout.box()
                min_materials_box.label(text="Minimize Button Material", icon='MATERIAL')
                min_materials_box.prop(window_props, "minimize_button_material")
                if window_props.minimize_button_material == 'CREATE_NEW':
                    min_materials_box.prop(window_props, "minimize_button_material_name")
                min_materials_box.prop(window_props, "minimize_button_transparency")
        
        layout.operator("mesh.add_ui_window", text="Create Window Panel", icon='ADD')

# Collapsible Button Panel Section
class VIEW3D_PT_ui_button_panel(Panel):
    """Collapsible Button Component Section"""
    bl_label = "Button Component"
    bl_idname = "VIEW3D_PT_ui_button_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        button_props = scene.ui_button_props
        layout.prop(button_props, "width")
        layout.prop(button_props, "height")
        layout.prop(button_props, "corner_radius")
        layout.prop(button_props, "bevel_segments")
        layout.prop(button_props, "depth")
        layout.prop(button_props, "border_width")
        
        # Main Material Properties for Button
        main_materials_box = layout.box()
        main_materials_box.label(text="Main Material", icon='MATERIAL')
        main_materials_box.prop(button_props, "main_material")
        if button_props.main_material == 'CREATE_NEW':
            main_materials_box.prop(button_props, "main_material_name")
        main_materials_box.prop(button_props, "main_transparency")
        
        # Border Material Properties for Button
        if button_props.border_width > 0.001:
            border_materials_box = layout.box()
            border_materials_box.label(text="Border Material", icon='MATERIAL')
            border_materials_box.prop(button_props, "border_material")
            if button_props.border_material == 'CREATE_NEW':
                border_materials_box.prop(button_props, "border_material_name")
            border_materials_box.prop(button_props, "border_transparency")
        
        layout.operator("mesh.add_ui_button", text="Create Button", icon='ADD')

# Collapsible Checkbox Panel Section
class VIEW3D_PT_ui_checkbox_panel(Panel):
    """Collapsible Enhanced Checkbox Component Section"""
    bl_label = "Enhanced Checkbox Component"
    bl_idname = "VIEW3D_PT_ui_checkbox_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        checkbox_props = scene.ui_checkbox_props
        layout.prop(checkbox_props, "shape_type")
        layout.prop(checkbox_props, "size")
        layout.prop(checkbox_props, "border_width")
        layout.prop(checkbox_props, "is_checked")
        
        # Main Material Properties for Checkbox
        main_materials_box = layout.box()
        main_materials_box.label(text="Main Material", icon='MATERIAL')
        main_materials_box.prop(checkbox_props, "main_material")
        if checkbox_props.main_material == 'CREATE_NEW':
            main_materials_box.prop(checkbox_props, "main_material_name")
        main_materials_box.prop(checkbox_props, "main_transparency")
        
        # Border Material Properties for Checkbox
        if checkbox_props.border_width > 0.001:
            border_materials_box = layout.box()
            border_materials_box.label(text="Border Material", icon='MATERIAL')
            border_materials_box.prop(checkbox_props, "border_material")
            if checkbox_props.border_material == 'CREATE_NEW':
                border_materials_box.prop(checkbox_props, "border_material_name")
            border_materials_box.prop(checkbox_props, "border_transparency")
        
        # Checked State Material Properties for Checkbox
        if checkbox_props.is_checked:
            checked_materials_box = layout.box()
            checked_materials_box.label(text="Checked State Material", icon='MATERIAL')
            checked_materials_box.prop(checkbox_props, "checked_material")
            if checkbox_props.checked_material == 'CREATE_NEW':
                checked_materials_box.prop(checkbox_props, "checked_material_name")
            checked_materials_box.prop(checkbox_props, "checked_transparency")
        
        layout.operator("mesh.add_ui_checkbox", text="Create Checkbox", icon='ADD')

# Enhanced Scrollbar Panel Section
class VIEW3D_PT_ui_scrollbar_panel(Panel):
    """Scrollbar creation and material settings"""
    bl_label = "Enhanced Scrollbar"
    bl_idname = "VIEW3D_PT_ui_scrollbar_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.ui_scrollbar_props

        layout.label(text="Dimensions:")
        layout.prop(props, "orientation")
        layout.prop(props, "length")
        layout.prop(props, "width")
        layout.prop(props, "arrow_size")

        layout.separator()
        layout.label(text="Appearance:")
        layout.prop(props, "corner_radius")
        layout.prop(props, "embossed")
        layout.prop(props, "emboss_depth")

        layout.separator()
        layout.label(text="Track Knob:")
        layout.prop(props, "has_track_knob")
        layout.prop(props, "track_knob_size")
        layout.prop(props, "track_knob_position")

        layout.separator()
        layout.label(text="Materials:")
        layout.prop(props, "track_material")
        layout.prop(props, "track_material_name")
        layout.prop(props, "track_transparency")

        layout.prop(props, "track_knob_material")
        layout.prop(props, "track_knob_material_name")
        layout.prop(props, "track_knob_transparency")

        layout.prop(props, "arrow_material")
        layout.prop(props, "arrow_material_name")
        layout.prop(props, "arrow_transparency")

        layout.operator("mesh.add_ui_scrollbar", text="Create Scrollbar")

# Enhanced Collapsible Slider Panel Section
class VIEW3D_PT_ui_slider_panel(Panel):
    """Enhanced Collapsible Slider Component Section with embossed appearance and curved corners"""
    bl_label = "Enhanced Slider Component"
    bl_idname = "VIEW3D_PT_ui_slider_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        slider_props = scene.ui_slider_props
        
        # Basic Properties Section
        basic_box = layout.box()
        basic_box.label(text="Basic Properties", icon='SETTINGS')
        basic_box.prop(slider_props, "orientation")
        basic_box.prop(slider_props, "length")
        basic_box.prop(slider_props, "track_width")
        basic_box.prop(slider_props, "knob_size")
        basic_box.prop(slider_props, "knob_position")
        basic_box.prop(slider_props, "border_width")
        
        # Enhanced Appearance Section
        appearance_box = layout.box()
        appearance_box.label(text="Enhanced Appearance", icon='SHADING_RENDERED')
        appearance_box.prop(slider_props, "corner_radius")
        appearance_box.prop(slider_props, "embossed")
        if slider_props.embossed:
            appearance_box.prop(slider_props, "emboss_depth")
        
        # Track Material Properties for Slider
        track_materials_box = layout.box()
        track_materials_box.label(text="Track Material", icon='MATERIAL')
        track_materials_box.prop(slider_props, "track_material")
        if slider_props.track_material == 'CREATE_NEW':
            track_materials_box.prop(slider_props, "track_material_name")
        track_materials_box.prop(slider_props, "track_transparency")
        
        # Knob Material Properties for Slider
        knob_materials_box = layout.box()
        knob_materials_box.label(text="Knob Material", icon='MATERIAL')
        knob_materials_box.prop(slider_props, "knob_material")
        if slider_props.knob_material == 'CREATE_NEW':
            knob_materials_box.prop(slider_props, "knob_material_name")
        knob_materials_box.prop(slider_props, "knob_transparency")
        
        # Border Material Properties for Slider
        if slider_props.border_width > 0.001:
            border_materials_box = layout.box()
            border_materials_box.label(text="Border Material", icon='MATERIAL')
            border_materials_box.prop(slider_props, "border_material")
            if slider_props.border_material == 'CREATE_NEW':
                border_materials_box.prop(slider_props, "border_material_name")
            border_materials_box.prop(slider_props, "border_transparency")
        
        layout.operator("mesh.add_ui_slider", text="Create Slider", icon='ADD')

# NEW: Individual Banner Panel Section - CRITICAL ADDITION
class VIEW3D_PT_ui_banner_panel(Panel):
    """Individual Banner Component Section with full material support"""
    bl_label = "Banner Component"
    bl_idname = "VIEW3D_PT_ui_banner_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        banner_props = scene.ui_banner_props
        
        # Basic Properties Section
        basic_box = layout.box()
        basic_box.label(text="Basic Properties", icon='SETTINGS')
        basic_box.prop(banner_props, "width")
        basic_box.prop(banner_props, "height")
        basic_box.prop(banner_props, "corner_radius")
        basic_box.prop(banner_props, "border_width")
        
        # Main Material Properties for Banner
        main_materials_box = layout.box()
        main_materials_box.label(text="Main Material", icon='MATERIAL')
        main_materials_box.prop(banner_props, "main_material")
        if banner_props.main_material == 'CREATE_NEW':
            main_materials_box.prop(banner_props, "main_material_name")
        main_materials_box.prop(banner_props, "main_transparency")
        
        # Border Material Properties for Banner
        if banner_props.border_width > 0.001:
            border_materials_box = layout.box()
            border_materials_box.label(text="Border Material", icon='MATERIAL')
            border_materials_box.prop(banner_props, "border_material")
            if banner_props.border_material == 'CREATE_NEW':
                border_materials_box.prop(banner_props, "border_material_name")
            border_materials_box.prop(banner_props, "border_transparency")
        
        layout.operator("mesh.add_ui_banner", text="Create Banner", icon='ADD')

# NEW: Individual General Panel Section - CRITICAL ADDITION
class VIEW3D_PT_ui_general_panel_panel(Panel):
    """Individual General Panel Component Section with full material support"""
    bl_label = "General Panel Component"
    bl_idname = "VIEW3D_PT_ui_general_panel_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        panel_props = scene.ui_general_panel_props
        
        # Basic Properties Section
        basic_box = layout.box()
        basic_box.label(text="Basic Properties", icon='SETTINGS')
        basic_box.prop(panel_props, "width")
        basic_box.prop(panel_props, "height")
        basic_box.prop(panel_props, "corner_radius")
        basic_box.prop(panel_props, "border_width")
        
        # Main Material Properties for General Panel
        main_materials_box = layout.box()
        main_materials_box.label(text="Main Material", icon='MATERIAL')
        main_materials_box.prop(panel_props, "main_material")
        if panel_props.main_material == 'CREATE_NEW':
            main_materials_box.prop(panel_props, "main_material_name")
        main_materials_box.prop(panel_props, "main_transparency")
        
        # Border Material Properties for General Panel
        if panel_props.border_width > 0.001:
            border_materials_box = layout.box()
            border_materials_box.label(text="Border Material", icon='MATERIAL')
            border_materials_box.prop(panel_props, "border_material")
            if panel_props.border_material == 'CREATE_NEW':
                border_materials_box.prop(panel_props, "border_material_name")
            border_materials_box.prop(panel_props, "border_transparency")
        
        layout.operator("mesh.add_ui_general_panel", text="Create General Panel", icon='ADD')

# Advanced UI Components panel for complex controls
class VIEW3D_PT_ui_components_advanced_panel(Panel):
    """Advanced UI Components panel for complex controls"""
    bl_label = "Advanced Components"
    bl_idname = "VIEW3D_PT_ui_components_advanced_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Tabbed Panel Section
        box = layout.box()
        box.label(text="Tabbed Panel System", icon='COLLAPSEMENU')
        
        tabbed_props = scene.ui_tabbed_panel_props
        box.prop(tabbed_props, "panel_width")
        box.prop(tabbed_props, "panel_height")
        box.prop(tabbed_props, "tab_height")
        box.prop(tabbed_props, "tab_count")
        box.prop(tabbed_props, "border_width")
        
        # Content Material Properties for Tabbed Panel
        content_materials_box = box.box()
        content_materials_box.label(text="Content Material", icon='MATERIAL')
        content_materials_box.prop(tabbed_props, "content_material")
        if tabbed_props.content_material == 'CREATE_NEW':
            content_materials_box.prop(tabbed_props, "content_material_name")
        content_materials_box.prop(tabbed_props, "content_transparency")
        
        # Active Tab Material Properties
        active_tab_materials_box = box.box()
        active_tab_materials_box.label(text="Active Tab Material", icon='MATERIAL')
        active_tab_materials_box.prop(tabbed_props, "active_tab_material")
        if tabbed_props.active_tab_material == 'CREATE_NEW':
            active_tab_materials_box.prop(tabbed_props, "active_tab_material_name")
        active_tab_materials_box.prop(tabbed_props, "active_tab_transparency")
        
        # Inactive Tab Material Properties
        inactive_tab_materials_box = box.box()
        inactive_tab_materials_box.label(text="Inactive Tab Material", icon='MATERIAL')
        inactive_tab_materials_box.prop(tabbed_props, "inactive_tab_material")
        if tabbed_props.inactive_tab_material == 'CREATE_NEW':
            inactive_tab_materials_box.prop(tabbed_props, "inactive_tab_material_name")
        inactive_tab_materials_box.prop(tabbed_props, "inactive_tab_transparency")
        
        box.operator("mesh.add_ui_tabbed_panel", text="Create Tabbed Panel", icon='ADD')

# System-level UI Components panel for complete window systems
class VIEW3D_PT_ui_components_system_panel(Panel):
    """System-level UI Components panel for complete window systems"""
    bl_label = "Complete Systems"
    bl_idname = "VIEW3D_PT_ui_components_system_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UI Components"  # FIXED: Consistent category naming
    bl_parent_id = "VIEW3D_PT_ui_components_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        # Combined Window System Section
        box = layout.box()
        box.label(text="Complete Window System", icon='WORKSPACE')
        box.label(text="Creates integrated window with components")
        
        box.operator("mesh.add_ui_combined_window", text="Create Complete System", icon='SCENE')

        # Enhanced Material Management Section
        box = layout.box()
        box.label(text="Enhanced Material Management", icon='MATERIAL')
        box.label(text="Advanced material features:")
        
        col = box.column(align=True)
        col.label(text="• Material selection dropdown")
        col.label(text="• Custom material naming")
        col.label(text="• Transparency controls")
        col.label(text="• Separate border materials")
        col.label(text="• Individual component materials")
        col.label(text="• Existing material reuse")

        # Enhanced Border System Section
        box = layout.box()
        box.label(text="Enhanced Border System", icon='MESH_CIRCLE')
        box.label(text="Inward border implementation:")
        
        col = box.column(align=True)
        col.label(text="• Borders go inward from edge")
        col.label(text="• Separate border materials")
        col.label(text="• Configurable border width")
        col.label(text="• Maintains component dimensions")
        col.label(text="• Supports transparency")

        # Enhanced Features Section (v1.0.12)
        box = layout.box()
        box.label(text="Fixed/Features (v1.0.12)", icon='CHECKMARK')
        box.label(text="Latest fixes:")
        
        col = box.column(align=True)
        col.label(text="• Added Banner individual panel")
        col.label(text="• Added Panel individual panel")
        col.label(text="• Complete material settings support")
        col.label(text="• Individual Create buttons")
        col.label(text="• Proper sidebar visibility")
        col.label(text="• Individual component access")
        col.label(text="• Sub Components Grouped")

        # Game Engine Export Information Section
        box = layout.box()
        box.label(text="CPGE Support", icon='EXPORT')
        box.label(text="Exports to include:")
        
        col = box.column(align=True)
        col.label(text="• Proper UV coordinates")
        col.label(text="• Normalized 0-1 UV space")
        col.label(text="• Individual material slots")
        col.label(text="• Production-ready meshes")